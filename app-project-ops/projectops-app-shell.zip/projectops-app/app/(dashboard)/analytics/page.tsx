import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function AnalyticsPage() {
  return (
    <ModulePlaceholder
      title="Analytics"
      description="The Analytics module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
