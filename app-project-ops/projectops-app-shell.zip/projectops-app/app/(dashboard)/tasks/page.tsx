import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function TasksPage() {
  return (
    <ModulePlaceholder
      title="Tasks"
      description="The Tasks module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
