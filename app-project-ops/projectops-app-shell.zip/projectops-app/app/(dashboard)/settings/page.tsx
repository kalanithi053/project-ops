import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function SettingsPage() {
  return (
    <ModulePlaceholder
      title="Settings"
      description="The Settings module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
