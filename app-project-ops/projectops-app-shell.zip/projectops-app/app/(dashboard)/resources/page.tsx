import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function ResourcesPage() {
  return (
    <ModulePlaceholder
      title="Resources"
      description="The Resources module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
