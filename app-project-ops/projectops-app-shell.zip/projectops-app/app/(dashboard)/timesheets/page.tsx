import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function TimesheetsPage() {
  return (
    <ModulePlaceholder
      title="Timesheets"
      description="The Timesheets module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
