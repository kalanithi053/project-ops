import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function CapacityPage() {
  return (
    <ModulePlaceholder
      title="Capacity"
      description="The Capacity module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
