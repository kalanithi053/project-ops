import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function DevelopersPage() {
  return (
    <ModulePlaceholder
      title="Developers"
      description="The Developers module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
