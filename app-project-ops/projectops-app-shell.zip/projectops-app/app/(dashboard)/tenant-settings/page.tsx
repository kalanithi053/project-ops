import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function TenantSettingsPage() {
  return (
    <ModulePlaceholder
      title="Tenant Settings"
      description="The Tenant Settings module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
