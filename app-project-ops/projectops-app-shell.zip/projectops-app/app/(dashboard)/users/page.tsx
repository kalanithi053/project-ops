import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function UsersPage() {
  return (
    <ModulePlaceholder
      title="Users"
      description="The Users module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
