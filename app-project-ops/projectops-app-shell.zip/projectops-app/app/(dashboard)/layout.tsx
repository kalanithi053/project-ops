import { TenantProvider } from "@/lib/tenant/tenant-context";
import { AppShell } from "@/components/layout/app-shell";
import { mockCurrentUser, mockNotifications } from "@/lib/mock/data";

/**
 * Shared layout for every authenticated route. This is where the
 * real session lookup will eventually live (fetching the current
 * user + tenant from the auth provider) — today it feeds mock data
 * into the same props the shell will consume from that session later.
 */
export default function DashboardGroupLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <TenantProvider>
      <AppShell user={mockCurrentUser} notifications={mockNotifications}>
        {children}
      </AppShell>
    </TenantProvider>
  );
}
