import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function AuditLogsPage() {
  return (
    <ModulePlaceholder
      title="Audit Logs"
      description="The Audit Logs module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
