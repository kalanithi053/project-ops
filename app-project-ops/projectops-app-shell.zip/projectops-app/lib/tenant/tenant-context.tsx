"use client";

import * as React from "react";

import type { Tenant } from "@/types/tenant";
import { mockTenants } from "@/lib/mock/data";

interface TenantContextValue {
  tenant: Tenant;
  tenants: Tenant[];
  setTenant: (tenant: Tenant) => void;
}

const TenantContext = React.createContext<TenantContextValue | null>(null);

/**
 * Provides the active tenant to the app shell.
 *
 * SECURITY NOTE: this is a UI convenience only. Switching tenants here
 * changes what the frontend *displays*; it does not grant access to
 * another tenant's data. The backend must always validate that the
 * authenticated session actually belongs to the requested tenant on
 * every request, independent of this client-side selection.
 *
 * Backed by React state for now — swap the initial value and setter
 * for a real session-derived tenant once auth/tenant APIs exist.
 */
export function TenantProvider({ children }: { children: React.ReactNode }) {
  const [tenant, setTenant] = React.useState<Tenant>(mockTenants[0]);

  const value = React.useMemo(
    () => ({ tenant, tenants: mockTenants, setTenant }),
    [tenant],
  );

  return (
    <TenantContext.Provider value={value}>{children}</TenantContext.Provider>
  );
}

export function useTenant() {
  const ctx = React.useContext(TenantContext);
  if (!ctx) {
    throw new Error("useTenant must be used within a TenantProvider");
  }
  return ctx;
}
