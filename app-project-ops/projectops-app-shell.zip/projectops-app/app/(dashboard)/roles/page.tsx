import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function RolesPage() {
  return (
    <ModulePlaceholder
      title="Users & Roles"
      description="The Users & Roles module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
