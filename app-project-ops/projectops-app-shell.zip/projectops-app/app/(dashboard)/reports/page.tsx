import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function ReportsPage() {
  return (
    <ModulePlaceholder
      title="Reports"
      description="The Reports module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
