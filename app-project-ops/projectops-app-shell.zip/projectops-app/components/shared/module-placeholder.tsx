import type { LucideIcon } from "lucide-react";
import { Construction } from "lucide-react";

import { PageContainer } from "@/components/layout/page-container";

interface ModulePlaceholderProps {
  title: string;
  description: string;
  icon?: LucideIcon;
}

/**
 * Stand-in for a module that hasn't been built yet. Keeps navigation
 * fully clickable during shell development without faking real
 * business pages, per the "no fake business pages" constraint.
 */
export function ModulePlaceholder({
  title,
  description,
  icon: Icon = Construction,
}: ModulePlaceholderProps) {
  return (
    <PageContainer>
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-border text-center">
        <Icon className="h-8 w-8 text-muted-foreground" />
        <h1 className="text-lg font-semibold">{title}</h1>
        <p className="max-w-sm text-sm text-muted-foreground">{description}</p>
      </div>
    </PageContainer>
  );
}
