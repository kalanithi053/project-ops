import {
  LayoutDashboard,
  FolderKanban,
  ListChecks,
  Rocket,
  Users,
  UsersRound,
  Code2,
  Boxes,
  Gauge,
  Clock,
  BarChart3,
  LineChart,
  Building2,
  ShieldCheck,
  ScrollText,
  Settings,
} from "lucide-react";

import type { NavigationSection } from "@/types/navigation";

/**
 * Single source of truth for the sidebar. Every future module registers
 * its entry point here instead of components hardcoding <Link> markup,
 * so adding a module never requires touching the sidebar component.
 */
export const navigationConfig: NavigationSection[] = [
  {
    items: [
      {
        label: "Dashboard",
        href: "/dashboard",
        icon: LayoutDashboard,
      },
    ],
  },
  {
    label: "Workspace",
    items: [
      {
        label: "Projects",
        href: "/projects",
        icon: FolderKanban,
        permission: "project:view",
      },
      {
        label: "Tasks",
        href: "/tasks",
        icon: ListChecks,
        permission: "task:view",
      },
      {
        label: "Sprints",
        href: "/sprints",
        icon: Rocket,
        permission: "sprint:view",
      },
    ],
  },
  {
    label: "People",
    items: [
      {
        label: "Users",
        href: "/users",
        icon: Users,
        permission: "user:view",
      },
      {
        label: "Teams",
        href: "/teams",
        icon: UsersRound,
        permission: "team:view",
      },
      {
        label: "Developers",
        href: "/developers",
        icon: Code2,
        permission: "developer:view",
      },
    ],
  },
  {
    label: "Operations",
    items: [
      {
        label: "Resources",
        href: "/resources",
        icon: Boxes,
        permission: "resource:view",
      },
      {
        label: "Capacity",
        href: "/capacity",
        icon: Gauge,
        permission: "capacity:view",
      },
      {
        label: "Timesheets",
        href: "/timesheets",
        icon: Clock,
        permission: "timesheet:view",
      },
    ],
  },
  {
    label: "Insights",
    items: [
      {
        label: "Reports",
        href: "/reports",
        icon: BarChart3,
        permission: "report:view",
      },
      {
        label: "Analytics",
        href: "/analytics",
        icon: LineChart,
        permission: "report:view",
      },
    ],
  },
  {
    label: "Administration",
    items: [
      {
        label: "Tenant Settings",
        href: "/tenant-settings",
        icon: Building2,
        permission: "tenant:manage",
      },
      {
        label: "Users & Roles",
        href: "/roles",
        icon: ShieldCheck,
        permission: "role:manage",
      },
      {
        label: "Audit Logs",
        href: "/audit-logs",
        icon: ScrollText,
        permission: "audit:view",
      },
      {
        label: "Settings",
        href: "/settings",
        icon: Settings,
      },
    ],
  },
];
