import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function ProjectsPage() {
  return (
    <ModulePlaceholder
      title="Projects"
      description="The Projects module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
