import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function SprintsPage() {
  return (
    <ModulePlaceholder
      title="Sprints"
      description="The Sprints module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
