import { ModulePlaceholder } from "@/components/shared/module-placeholder";

export default function TeamsPage() {
  return (
    <ModulePlaceholder
      title="Teams"
      description="The Teams module has not been built yet. This page validates that navigation and the application shell are wired up correctly."
    />
  );
}
