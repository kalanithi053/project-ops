import {
  FolderKanban,
  Users,
  ListChecks,
  AlertTriangle,
  Rocket,
  ClipboardList,
  PackageCheck,
} from "lucide-react";

import { PageContainer } from "@/components/layout/page-container";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { mockCurrentUser } from "@/lib/mock/data";

const kpis = [
  { label: "Active Projects", value: 12, icon: FolderKanban },
  { label: "Active Developers", value: 48, icon: Users },
  { label: "Open Tasks", value: 126, icon: ListChecks },
  { label: "At-Risk Projects", value: 3, icon: AlertTriangle },
];

const projectHealth = [
  { label: "On Track", count: 8, variant: "success" as const },
  { label: "At Risk", count: 3, variant: "warning" as const },
  { label: "Delayed", count: 1, variant: "error" as const },
];

const recentActivity = [
  { icon: FolderKanban, text: "Project Alpha moved to QA", time: "10m ago" },
  { icon: ClipboardList, text: "John assigned TASK-102", time: "1h ago" },
  { icon: Rocket, text: "Sprint 12 started", time: "5h ago" },
  { icon: PackageCheck, text: "Release v2.1 created", time: "1d ago" },
];

const developerCapacity = [
  { label: "Available", count: 14, variant: "info" as const },
  { label: "Optimal", count: 22, variant: "success" as const },
  { label: "High Utilization", count: 9, variant: "warning" as const },
  { label: "Overallocated", count: 3, variant: "error" as const },
];

export default function DashboardPage() {
  return (
    <PageContainer className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">
          Good morning, {mockCurrentUser.name}
        </h1>
        <p className="text-sm text-muted-foreground">
          Here&apos;s what&apos;s happening across your engineering workspace.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label}>
            <CardHeader className="flex-row items-center justify-between space-y-0 pb-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {kpi.label}
              </CardTitle>
              <kpi.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-semibold">{kpi.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Project Health</CardTitle>
            <CardDescription>Status across all active projects</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            {projectHealth.map((item) => (
              <div key={item.label} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge variant={item.variant}>{item.label}</Badge>
                </div>
                <span className="text-sm font-medium">{item.count}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest updates across your workspace</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="flex flex-col">
              {recentActivity.map((activity, index) => (
                <li key={activity.text}>
                  {index > 0 && <Separator className="my-3" />}
                  <div className="flex items-start gap-3">
                    <activity.icon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm">{activity.text}</p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Developer Capacity</CardTitle>
            <CardDescription>Utilization across the org</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            {developerCapacity.map((item) => (
              <div key={item.label} className="flex items-center justify-between">
                <Badge variant={item.variant}>{item.label}</Badge>
                <span className="text-sm font-medium">{item.count}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </PageContainer>
  );
}
