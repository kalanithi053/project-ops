"use client";

import { Building2, Check, ChevronsUpDown } from "lucide-react";

import { useTenant } from "@/lib/tenant/tenant-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

/**
 * Lets the user switch which tenant's data they're viewing.
 *
 * SECURITY NOTE: this selector is a UI convenience, not a security
 * boundary — see TenantProvider. The backend must independently
 * validate tenant access on every request.
 */
export function TenantSelector() {
  const { tenant, tenants, setTenant } = useTenant();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="hidden max-w-48 gap-2 sm:flex"
        >
          <Building2 className="h-4 w-4 shrink-0 text-muted-foreground" />
          <span className="truncate">{tenant.name}</span>
          <ChevronsUpDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>Switch tenant</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {tenants.map((t) => (
          <DropdownMenuItem
            key={t.id}
            onSelect={() => setTenant(t)}
            className="justify-between"
          >
            <span className="truncate">{t.name}</span>
            {t.id === tenant.id && <Check className="h-4 w-4 shrink-0" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
